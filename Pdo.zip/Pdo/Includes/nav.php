<!DOCTYPE html>
<html>
<head>
	<title></title>

<!-- <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet"> -->
<style>
</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container">
  <a class="navbar-brand" href="#">Product</a>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/Pdo/indx.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Pdo/Registration.php">Sign Up</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Pdo/cook_log.php">Sign in</a>
      </li>
      <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">More!</a>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../Admin/add_prod.php">Add product</a>
      <a class="dropdown-item" href="../Includes/product.php">View product</a>
      <a class="dropdown-item" href="../User/myprof.php">My profile</a>
      <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="/Pdo/logout.php">Logout</a>
    </div>
  </li>
<!-- <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
      
    </ul>
  </div>
  </div>
</nav>
</body>
</html>